-- Compact page generated from a user-provided French Gen I ROM.
-- The source ROM and complete extracted font remain private/ignored.
return {
  localized = {
    image = "assets/font/localized.png",
    base = 0x100,
    glyphsPerRow = 19,
  },
}
