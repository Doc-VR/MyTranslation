-- Generated qid-driven literal dialogue handlers.
return function(mod)
  local TextBox = mod.ui.TextBox
  local ChoiceBox = mod.ui.ChoiceBox
  mod.content.map_scripts:register("VIRIDIAN_CITY", {talk = {
    ["TEXT_VIRIDIANCITY_YOUNGSTER2"] = function(game, ow, npc, done)
      game.stack:push(TextBox.new(game, "Tu veux tout\nsavoir sur les 2\11types de chenille\11POKéMON?", function()
        game.stack:push(ChoiceBox.new(game, function(yes)
          game.stack:push(TextBox.new(game, yes and "Contrairement à\nCHENIPAN, ASPICOT\11est venimeux.\12Attention à son\nDARD-VENIN!" or "Bon. OK.", done))
        end))
      end))
    end,
  },
  })
  mod.content.map_scripts:register("MUSEUM_1F", {talk = {
    ["TEXT_MUSEUM1F_SCIENTIST1"] = function(game, ow, npc, done)
      if game.save.flags["EVENT_BOUGHT_MUSEUM_TICKET"] then
        game.stack:push(TextBox.new(game, "Prends tout ton\ntemps pour\11regarder!", done))
      else
        game.stack:push(TextBox.new(game, "50¥ le ticket\npour un enfant.\12Voulez-vous\nentrer?", function()
          game.stack:push(ChoiceBox.new(game, function(yes)
            if yes then
              if (game.save.money or 0) >= 50 then
                game.save.money = (game.save.money or 0) + (-50)
                game.save.flags["EVENT_BOUGHT_MUSEUM_TICKET"] = true
                game.stack:push(TextBox.new(game, "50¥! Parfait!\nMerci!", done))
              else
                game.stack:push(TextBox.new(game, "Vous n'avez pas\nassez d'argent.", done))
              end
            else
              game.stack:push(TextBox.new(game, "A bientôt!", done))
            end
          end))
        end))
      end
    end,
  },
    onStep = function(game, ow, x, y)
      if ((x == 9 and y == 4) or (x == 10 and y == 4)) and not game.save.flags["EVENT_BOUGHT_MUSEUM_TICKET"] then
        local function on_done() end
        game.stack:push(TextBox.new(game, "50¥ le ticket\npour un enfant.\12Voulez-vous\nentrer?", function()
          game.stack:push(ChoiceBox.new(game, function(yes)
            if yes then
              if (game.save.money or 0) >= 50 then
                game.save.money = (game.save.money or 0) + (-50)
                game.save.flags["EVENT_BOUGHT_MUSEUM_TICKET"] = true
                game.stack:push(TextBox.new(game, "50¥! Parfait!\nMerci!", on_done))
              else
                game.stack:push(TextBox.new(game, "Vous n'avez pas\nassez d'argent.", function()
                  ow:scriptMove(ow.player, "down", 1, on_done)
                end))
              end
            else
              game.stack:push(TextBox.new(game, "A bientôt!", function()
                ow:scriptMove(ow.player, "down", 1, on_done)
              end))
            end
          end))
        end))
        return true
      end
      return false
    end,
  })
  mod.content.map_scripts:register("BIKE_SHOP", {talk = {
    ["TEXT_BIKESHOP_CLERK"] = function(game, ow, npc, done)
      if (game.save.inventory["BICYCLE"] or 0) > 0 then
        game.stack:push(TextBox.new(game, "Comment se porte\nta BICYCLETTE?\12Tu peux aller sur\nla PISTE CYCLABLE\11et dans les\11GROTTES!", done))
      else
        if (game.save.inventory["BIKE_VOUCHER"] or 0) > 0 then
          game.stack:push(TextBox.new(game, "Oh! Mais c'est...\12Un BON pour\nune BICYCLETTE!\12OK! Voilà ta\nBICYCLETTE!", function()
            game.save.inventory["BIKE_VOUCHER"] = nil
            game.save.inventory["BICYCLE"] = 1
            game.save.flags["EVENT_GOT_BICYCLE"] = true
            game.stack:push(TextBox.new(game, "{PLAYER} échange\nle BON contre\11une BICYCLETTE.", done))
          end))
        else
          game.stack:push(TextBox.new(game, "Bienvenue au\nCYCLES A GOGO.\12Nous avons\njustement une\11belle bicyclette!", done))
        end
      end
    end,
  },
  })
  mod.content.map_scripts:register("BIKE_SHOP", {talk = {
    ["TEXT_BIKESHOP_MIDDLE_AGED_WOMAN"] = function(game, ow, npc, done)
      game.stack:push(TextBox.new(game, "Un VELO de ville,\nc'est ce qu'il y\11a de mieux!\12Il n'y a pas de\nporte-bagages sur\11un VTT!", done))
    end,
  },
  })
  mod.content.map_scripts:register("BIKE_SHOP", {talk = {
    ["TEXT_BIKESHOP_YOUNGSTER"] = function(game, ow, npc, done)
      if (game.save.flags["EVENT_GOT_BICYCLE"] or (game.save.inventory["BICYCLE"] or 0) > 0) then
        game.stack:push(TextBox.new(game, "Waou! \nTa BICYCLETTE est\11super cool!", done))
      else
        game.stack:push(TextBox.new(game, "Ces VELOS sont\nsuper mais ils\11sont très chers!", done))
      end
    end,
  },
  })
end
